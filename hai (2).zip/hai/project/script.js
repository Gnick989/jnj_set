document.addEventListener('DOMContentLoaded', async () => {
  try {
    const response = await fetch('/api/blockchain');
    const blockchain = await response.json();
    
    const statsElement = document.getElementById('blockchain-stats');
    
    if (blockchain && blockchain.chain) {
      const totalBlocks = blockchain.chain.length;
      const totalPapers = totalBlocks - 1; // Subtract genesis block
      
      // Get unique subjects and departments
      const subjects = new Set();
      const departments = new Set();
      
      for (let i = 1; i < blockchain.chain.length; i++) {
        const paper = blockchain.chain[i].data;
        if (paper.subject) subjects.add(paper.subject);
        if (paper.department) departments.add(paper.department);
      }
      
      statsElement.innerHTML = `
        <p><strong>Total Blocks:</strong> ${totalBlocks}</p>
        <p><strong>Question Papers:</strong> ${totalPapers}</p>
        <p><strong>Unique Subjects:</strong> ${subjects.size}</p>
        <p><strong>Departments:</strong> ${departments.size}</p>
        <p><strong>Blockchain Difficulty:</strong> ${blockchain.difficulty}</p>
        <p><strong>Last Updated:</strong> ${new Date().toLocaleString()}</p>
      `;
    } else {
      statsElement.innerHTML = '<p>No blockchain data available</p>';
    }
  } catch (error) {
    console.error('Error fetching blockchain data:', error);
    document.getElementById('blockchain-stats').innerHTML = 
      '<p class="error">Error loading blockchain data. Please ensure the server is running.</p>';
  }
});