const express = require('express');
const bodyParser = require('body-parser');
const { Block, Blockchain } = require('./blockchain');
const path = require('path');

const app = express();
const PORT = 3000;

// Middleware
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, '/')));

// Initialize blockchain
const questionPaperChain = new Blockchain();

// Routes
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

app.get('/api/blockchain', (req, res) => {
  res.json(questionPaperChain);
});

app.get('/api/papers', (req, res) => {
  const papers = [];
  for (let i = 1; i < questionPaperChain.chain.length; i++) {
    papers.push(questionPaperChain.chain[i].data);
  }
  res.json(papers);
});

app.get('/api/papers/:id', (req, res) => {
  const paper = questionPaperChain.getQuestionPaperById(req.params.id);
  if (paper) {
    res.json(paper);
  } else {
    res.status(404).json({ message: 'Question paper not found' });
  }
});

app.get('/api/papers/subject/:subject', (req, res) => {
  const papers = questionPaperChain.getQuestionPapersBySubject(req.params.subject);
  res.json(papers);
});

app.get('/api/papers/department/:department', (req, res) => {
  const papers = questionPaperChain.getQuestionPapersByDepartment(req.params.department);
  res.json(papers);
});

app.post('/api/papers', (req, res) => {
  const { id, title, subject, department, questions, createdBy, examDate } = req.body;
  
  if (!id || !title || !subject || !department || !questions || !createdBy) {
    return res.status(400).json({ message: 'Missing required fields' });
  }

  const newPaper = {
    id,
    title,
    subject,
    department,
    questions,
    createdBy,
    examDate,
    createdAt: new Date().toISOString()
  };

  const newBlock = new Block(Date.now(), newPaper);
  questionPaperChain.addBlock(newBlock);

  res.status(201).json({ 
    message: 'Question paper added to blockchain',
    block: newBlock
  });
});

app.get('/api/validate', (req, res) => {
  const isValid = questionPaperChain.isChainValid();
  res.json({ valid: isValid });
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});