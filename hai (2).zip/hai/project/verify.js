document.addEventListener('DOMContentLoaded', async () => {
  const verifyBtn = document.getElementById('verify-btn');
  const verificationResult = document.getElementById('verification-result');
  const blockchainBlocks = document.getElementById('blockchain-blocks');
  
  // Function to load blockchain data
  async function loadBlockchainData() {
    try {
      blockchainBlocks.innerHTML = '<p>Loading blockchain data...</p>';
      
      const response = await fetch('/api/blockchain');
      const blockchain = await response.json();
      
      if (!blockchain || !blockchain.chain || blockchain.chain.length === 0) {
        blockchainBlocks.innerHTML = '<p>No blockchain data available</p>';
        return;
      }
      
      blockchainBlocks.innerHTML = '';
      
      // Display blocks in reverse order (newest first)
      blockchain.chain.slice().reverse().forEach((block, index) => {
        const actualIndex = blockchain.chain.length - 1 - index;
        const isGenesis = actualIndex === 0;
        
        const blockItem = document.createElement('div');
        blockItem.className = 'block-item';
        
        let blockContent = `
          <h3>Block #${actualIndex} ${isGenesis ? '(Genesis Block)' : ''}</h3>
          <p><strong>Hash:</strong> <span class="block-hash">${block.hash}</span></p>
          <p><strong>Previous Hash:</strong> <span class="block-hash">${block.previousHash}</span></p>
          <p class="block-timestamp"><strong>Timestamp:</strong> ${new Date(block.timestamp).toLocaleString()}</p>
        `;
        
        if (!isGenesis) {
          blockContent += `
            <div class="block-data">
              <details>
                <summary>Block Data</summary>
                <p><strong>Paper ID:</strong> ${block.data.id}</p>
                <p><strong>Title:</strong> ${block.data.title}</p>
                <p><strong>Subject:</strong> ${block.data.subject}</p>
                <p><strong>Department:</strong> ${block.data.department}</p>
                <p><strong>Questions:</strong> ${block.data.questions.length}</p>
                <p><strong>Created By:</strong> ${block.data.createdBy}</p>
              </details>
            </div>
          `;
        } else {
          blockContent += `
            <div class="block-data">
              <details>
                <summary>Genesis Block Data</summary>
                <pre>${JSON.stringify(block.data, null, 2)}</pre>
              </details>
            </div>
          `;
        }
        
        blockItem.innerHTML = blockContent;
        blockchainBlocks.appendChild(blockItem);
      });
    } catch (error) {
      console.error('Error loading blockchain data:', error);
      blockchainBlocks.innerHTML = '<p class="error">Error loading blockchain data. Please ensure the server is running.</p>';
    }
  }
  
  // Load blockchain data on page load
  await loadBlockchainData();
  
  // Verify blockchain integrity
  verifyBtn.addEventListener('click', async () => {
    try {
      verificationResult.innerHTML = '<p>Verifying blockchain integrity...</p>';
      verificationResult.className = '';
      
      const response = await fetch('/api/validate');
      const result = await response.json();
      
      if (result.valid) {
        verificationResult.innerHTML = `
          <p>✅ Blockchain verification successful!</p>
          <p>The blockchain is valid and has not been tampered with.</p>
          <p>All question papers are secure and their integrity is maintained.</p>
        `;
        verificationResult.className = 'valid';
      } else {
        verificationResult.innerHTML = `
          <p>❌ Blockchain verification failed!</p>
          <p>The blockchain has been tampered with or is invalid.</p>
          <p>This indicates potential security issues with the question papers.</p>
        `;
        verificationResult.className = 'invalid';
      }
    } catch (error) {
      console.error('Error verifying blockchain:', error);
      verificationResult.innerHTML = '<p>Error: Could not connect to the server</p>';
      verificationResult.className = 'error';
    }
  });
});