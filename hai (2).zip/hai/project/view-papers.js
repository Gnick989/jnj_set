document.addEventListener('DOMContentLoaded', async () => {
  const papersList = document.getElementById('papers-list');
  const filterSubjectBtn = document.getElementById('apply-subject-filter');
  const filterDepartmentBtn = document.getElementById('apply-department-filter');
  const clearFiltersBtn = document.getElementById('clear-filters');
  
  // Function to fetch and display papers
  async function fetchPapers(url = '/api/papers') {
    try {
      papersList.innerHTML = '<p>Loading question papers...</p>';
      
      const response = await fetch(url);
      const papers = await response.json();
      
      if (papers.length === 0) {
        papersList.innerHTML = '<p>No question papers found.</p>';
        return;
      }
      
      papersList.innerHTML = '';
      
      papers.forEach(paper => {
        const paperCard = document.createElement('div');
        paperCard.className = 'paper-card';
        
        // Calculate total marks
        const totalMarks = paper.questions.reduce((sum, q) => sum + (parseInt(q.marks) || 0), 0);
        
        paperCard.innerHTML = `
          <h3 class="paper-title">${paper.title}</h3>
          <div class="paper-meta">
            <p><strong>ID:</strong> ${paper.id}</p>
            <p><strong>Subject:</strong> ${paper.subject}</p>
            <p><strong>Department:</strong> ${paper.department}</p>
            <p><strong>Exam Date:</strong> ${new Date(paper.examDate).toLocaleDateString()}</p>
            <p><strong>Created By:</strong> ${paper.createdBy}</p>
            <p><strong>Total Questions:</strong> ${paper.questions.length}</p>
            <p><strong>Total Marks:</strong> ${totalMarks}</p>
          </div>
          <div class="paper-questions">
            <details>
              <summary>View Questions (${paper.questions.length})</summary>
              <ol>
                ${paper.questions.map(q => `<li>${q.text} <strong>(${q.marks} marks)</strong></li>`).join('')}
              </ol>
            </details>
          </div>
        `;
        
        papersList.appendChild(paperCard);
      });
    } catch (error) {
      console.error('Error fetching papers:', error);
      papersList.innerHTML = '<p class="error">Error loading question papers. Please ensure the server is running.</p>';
    }
  }
  
  // Initial load of all papers
  await fetchPapers();
  
  // Filter by subject
  filterSubjectBtn.addEventListener('click', async () => {
    const subject = document.getElementById('filter-subject').value.trim();
    if (subject) {
      await fetchPapers(`/api/papers/subject/${encodeURIComponent(subject)}`);
    }
  });
  
  // Filter by department
  filterDepartmentBtn.addEventListener('click', async () => {
    const department = document.getElementById('filter-department').value.trim();
    if (department) {
      await fetchPapers(`/api/papers/department/${encodeURIComponent(department)}`);
    }
  });
  
  // Clear filters
  clearFiltersBtn.addEventListener('click', async () => {
    document.getElementById('filter-subject').value = '';
    document.getElementById('filter-department').value = '';
    await fetchPapers();
  });
});