document.addEventListener('DOMContentLoaded', async () => {
  try {
    const response = await fetch('/api/blockchain');
    const blockchain = await response.json();
    
    const statsElement = document.getElementById('blockchain-stats');
    
    if (blockchain && blockchain.chain) {
      const totalBlocks = blockchain.chain.length;
      const totalPapers = totalBlocks - 1; // Subtract genesis block
      
      // Get unique subjects and departments
      const subjects = new Set();
      const departments = new Set();
      
      for (let i = 1; i < blockchain.chain.length; i++) {
        const paper = blockchain.chain[i].data;
        if (paper.subject) subjects.add(paper.subject);
        if (paper.department) departments.add(paper.department);
      }
      
      statsElement.innerHTML = `
        <p><strong>Total Blocks:</strong> ${totalBlocks}</p>
        <p><strong>Question Papers:</strong> ${totalPapers}</p>
        <p><strong>Unique Subjects:</strong> ${subjects.size}</p>
        <p><strong>Departments:</strong> ${departments.size}</p>
        <p><strong>Blockchain Difficulty:</strong> ${blockchain.difficulty}</p>
        <p><strong>Last Updated:</strong> ${new Date().toLocaleString()}</p>
      `;
    } else {
      showDemoStats();
    }
  } catch (error) {
    console.error('Error fetching blockchain data:', error);
    showDemoStats();
  }
  
  function showDemoStats() {
    const statsElement = document.getElementById('blockchain-stats');
    statsElement.innerHTML = `
      <p><strong>Total Blocks:</strong> 4</p>
      <p><strong>Question Papers:</strong> 3</p>
      <p><strong>Unique Subjects:</strong> 3</p>
      <p><strong>Departments:</strong> 3</p>
      <p><strong>Blockchain Difficulty:</strong> 2</p>
      <p><strong>Last Updated:</strong> ${new Date().toLocaleString()}</p>
      <p class="demo-note">Note: Showing demo data. Connect to server for real data.</p>
    `;
  }
});