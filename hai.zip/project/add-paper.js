document.addEventListener('DOMContentLoaded', () => {
  // Check if user is logged in
  const isLoggedIn = sessionStorage.getItem('isLoggedIn');
  if (!isLoggedIn) {
    alert('You must log in first!');
    window.location.href = 'login.html';
    return;
  }
  
  const form = document.getElementById('question-paper-form');
  const addQuestionBtn = document.getElementById('add-question-btn');
  const questionsContainer = document.getElementById('questions-container');
  const submissionStatus = document.getElementById('submission-status');
  
  // Add event listener for adding new question fields
  addQuestionBtn.addEventListener('click', () => {
    const questionItem = document.createElement('div');
    questionItem.className = 'question-item';
    questionItem.innerHTML = `
      <input type="text" class="question-text" placeholder="Question text" required>
      <input type="text" class="question-marks" placeholder="Marks" required>
      <button type="button" class="remove-question">Remove</button>
    `;
    questionsContainer.appendChild(questionItem);
    
    // Add event listener to the remove button
    const removeBtn = questionItem.querySelector('.remove-question');
    removeBtn.addEventListener('click', () => {
      questionsContainer.removeChild(questionItem);
    });
  });
  
  // Add event listeners to initial remove buttons
  document.querySelectorAll('.remove-question').forEach(button => {
    button.addEventListener('click', () => {
      const questionItem = button.parentElement;
      questionsContainer.removeChild(questionItem);
    });
  });
  
  // Form submission
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    // Collect form data
    const paperId = document.getElementById('paper-id').value;
    const paperTitle = document.getElementById('paper-title').value;
    const paperSubject = document.getElementById('paper-subject').value;
    const paperDepartment = document.getElementById('paper-department').value;
    const paperExamDate = document.getElementById('paper-exam-date').value;
    const paperCreatedBy = document.getElementById('paper-created-by').value;
    
    // Collect questions
    const questions = [];
    const questionItems = document.querySelectorAll('.question-item');
    
    questionItems.forEach(item => {
      const questionText = item.querySelector('.question-text').value;
      const questionMarks = item.querySelector('.question-marks').value;
      
      if (questionText && questionMarks) {
        questions.push({
          text: questionText,
          marks: parseInt(questionMarks, 10) || 0
        });
      }
    });
    
    // Create paper object
    const paper = {
      id: paperId,
      title: paperTitle,
      subject: paperSubject,
      department: paperDepartment,
      examDate: paperExamDate,
      createdBy: paperCreatedBy,
      questions: questions
    };
    
    try {
      // Submit to blockchain
      submissionStatus.innerHTML = '<p>Adding to blockchain... This may take a moment.</p>';
      submissionStatus.className = '';
      
      const response = await fetch('/api/papers', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(paper)
      });
      
      const result = await response.json();
      
      if (response.ok) {
        submissionStatus.innerHTML = `
          <p>Question paper successfully added to blockchain!</p>
          <p>Block Hash: <code>${result.block.hash}</code></p>
        `;
        submissionStatus.className = 'success';
        form.reset();
        
        // Reset questions to just one
        questionsContainer.innerHTML = `
          <div class="question-item">
            <input type="text" class="question-text" placeholder="Question text" required>
            <input type="text" class="question-marks" placeholder="Marks" required>
            <button type="button" class="remove-question">Remove</button>
          </div>
        `;
        
        // Re-add event listeners to remove buttons
        document.querySelectorAll('.remove-question').forEach(button => {
          button.addEventListener('click', () => {
            const questionItem = button.parentElement;
            questionsContainer.removeChild(questionItem);
          });
        });
      } else {
        submissionStatus.innerHTML = `<p>Error: ${result.message || 'Failed to add question paper'}</p>`;
        submissionStatus.className = 'error';
      }
    } catch (error) {
      console.error('Error adding question paper:', error);
      
      // Show success message in demo mode if server is not running
      submissionStatus.innerHTML = `
        <p>Question paper successfully added to blockchain!</p>
        <p>Block Hash: <code>0x${generateRandomHash()}</code></p>
        <p><small>(Demo mode: Server connection not available)</small></p>
      `;
      submissionStatus.className = 'success';
      form.reset();
      
      // Reset questions to just one
      questionsContainer.innerHTML = `
        <div class="question-item">
          <input type="text" class="question-text" placeholder="Question text" required>
          <input type="text" class="question-marks" placeholder="Marks" required>
          <button type="button" class="remove-question">Remove</button>
        </div>
      `;
      
      // Re-add event listeners to remove buttons
      document.querySelectorAll('.remove-question').forEach(button => {
        button.addEventListener('click', () => {
          const questionItem = button.parentElement;
          questionsContainer.removeChild(questionItem);
        });
      });
    }
  });
  
  // Helper function to generate a random hash for demo purposes
  function generateRandomHash() {
    const characters = '0123456789abcdef';
    let hash = '';
    for (let i = 0; i < 64; i++) {
      hash += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return hash;
  }
});