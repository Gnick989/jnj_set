document.addEventListener('DOMContentLoaded', async () => {
  // Check if user is logged in
  const isLoggedIn = sessionStorage.getItem('isLoggedIn');
  if (!isLoggedIn) {
    alert('You must log in first!');
    window.location.href = 'login.html';
    return;
  }
  
  const papersList = document.getElementById('papers-list');
  const filterSubjectBtn = document.getElementById('apply-subject-filter');
  const filterDepartmentBtn = document.getElementById('apply-department-filter');
  const clearFiltersBtn = document.getElementById('clear-filters');
  
  // Function to fetch and display papers
  async function fetchPapers(url = '/api/papers') {
    try {
      papersList.innerHTML = '<p>Loading question papers...</p>';
      
      const response = await fetch(url);
      const papers = await response.json();
      
      if (papers.length === 0) {
        papersList.innerHTML = '<p>No question papers found.</p>';
        return;
      }
      
      papersList.innerHTML = '';
      
      papers.forEach(paper => {
        const paperCard = document.createElement('div');
        paperCard.className = 'paper-card';
        
        // Calculate total marks
        const totalMarks = paper.questions.reduce((sum, q) => sum + (parseInt(q.marks) || 0), 0);
        
        paperCard.innerHTML = `
          <h3 class="paper-title">${paper.title}</h3>
          <div class="paper-meta">
            <p><strong>ID:</strong> ${paper.id}</p>
            <p><strong>Subject:</strong> ${paper.subject}</p>
            <p><strong>Department:</strong> ${paper.department}</p>
            <p><strong>Exam Date:</strong> ${new Date(paper.examDate).toLocaleDateString()}</p>
            <p><strong>Created By:</strong> ${paper.createdBy}</p>
            <p><strong>Total Questions:</strong> ${paper.questions.length}</p>
            <p><strong>Total Marks:</strong> ${totalMarks}</p>
          </div>
          <div class="paper-questions">
            <details>
              <summary>View Questions (${paper.questions.length})</summary>
              <ol>
                ${paper.questions.map(q => `<li>${q.text} <strong>(${q.marks} marks)</strong></li>`).join('')}
              </ol>
            </details>
          </div>
        `;
        
        papersList.appendChild(paperCard);
      });
    } catch (error) {
      console.error('Error fetching papers:', error);
      // Show demo data if server is not running
      showDemoPapers();
    }
  }
  
  // Function to show demo papers when server is not running
  function showDemoPapers() {
    const demoPapers = [
      {
        id: "CS101-2025",
        title: "Introduction to Computer Science",
        subject: "Computer Science",
        department: "Computer Science and Engineering",
        examDate: "2025-05-15",
        createdBy: "Prof. Johnson",
        questions: [
          { text: "Explain the concept of object-oriented programming.", marks: 10 },
          { text: "Describe the difference between stack and queue data structures.", marks: 8 },
          { text: "What is the time complexity of quicksort in the worst case?", marks: 5 },
          { text: "Explain the working of a binary search algorithm.", marks: 7 }
        ]
      },
      {
        id: "EE202-2025",
        title: "Digital Electronics",
        subject: "Electronics",
        department: "Electrical Engineering",
        examDate: "2025-06-10",
        createdBy: "Prof. Williams",
        questions: [
          { text: "Design a 4-bit synchronous counter using JK flip-flops.", marks: 15 },
          { text: "Explain the working principle of a D/A converter.", marks: 10 },
          { text: "Implement a full adder circuit using NAND gates only.", marks: 10 }
        ]
      },
      {
        id: "ME301-2025",
        title: "Thermodynamics",
        subject: "Mechanical Engineering",
        department: "Mechanical Engineering",
        examDate: "2025-05-20",
        createdBy: "Prof. Smith",
        questions: [
          { text: "State and explain the first law of thermodynamics.", marks: 8 },
          { text: "Derive the expression for Carnot efficiency.", marks: 12 },
          { text: "Explain the working of a four-stroke engine with diagrams.", marks: 15 }
        ]
      }
    ];
    
    papersList.innerHTML = '';
    
    demoPapers.forEach(paper => {
      const paperCard = document.createElement('div');
      paperCard.className = 'paper-card';
      
      // Calculate total marks
      const totalMarks = paper.questions.reduce((sum, q) => sum + (parseInt(q.marks) || 0), 0);
      
      paperCard.innerHTML = `
        <h3 class="paper-title">${paper.title}</h3>
        <div class="paper-meta">
          <p><strong>ID:</strong> ${paper.id}</p>
          <p><strong>Subject:</strong> ${paper.subject}</p>
          <p><strong>Department:</strong> ${paper.department}</p>
          <p><strong>Exam Date:</strong> ${new Date(paper.examDate).toLocaleDateString()}</p>
          <p><strong>Created By:</strong> ${paper.createdBy}</p>
          <p><strong>Total Questions:</strong> ${paper.questions.length}</p>
          <p><strong>Total Marks:</strong> ${totalMarks}</p>
        </div>
        <div class="paper-questions">
          <details>
            <summary>View Questions (${paper.questions.length})</summary>
            <ol>
              ${paper.questions.map(q => `<li>${q.text} <strong>(${q.marks} marks)</strong></li>`).join('')}
            </ol>
          </details>
        </div>
      `;
      
      papersList.appendChild(paperCard);
    });
    
    // Add a note that these are demo papers
    const demoNote = document.createElement('div');
    demoNote.className = 'demo-note';
    demoNote.innerHTML = '<p>Note: Showing demo question papers. Connect to server for real data.</p>';
    papersList.prepend(demoNote);
  }
  
  // Initial load of papers
  await fetchPapers();
  
  // Filter by subject
  filterSubjectBtn.addEventListener('click', async () => {
    const subject = document.getElementById('filter-subject').value.trim();
    if (subject) {
      try {
        await fetchPapers(`/api/papers/subject/${encodeURIComponent(subject)}`);
      } catch (error) {
        console.error('Error filtering by subject:', error);
        // Filter demo papers if server is not running
        filterDemoPapersBySubject(subject);
      }
    }
  });
  
  // Filter by department
  filterDepartmentBtn.addEventListener('click', async () => {
    const department = document.getElementById('filter-department').value.trim();
    if (department) {
      try {
        await fetchPapers(`/api/papers/department/${encodeURIComponent(department)}`);
      } catch (error) {
        console.error('Error filtering by department:', error);
        // Filter demo papers if server is not running
        filterDemoPapersByDepartment(department);
      }
    }
  });
  
  // Filter demo papers by subject
  function filterDemoPapersBySubject(subject) {
    showDemoPapers();
    const paperCards = document.querySelectorAll('.paper-card');
    paperCards.forEach(card => {
      const paperSubject = card.querySelector('.paper-meta p:nth-child(2)').textContent;
      if (!paperSubject.toLowerCase().includes(subject.toLowerCase())) {
        card.style.display = 'none';
      }
    });
  }
  
  // Filter demo papers by department
  function filterDemoPapersByDepartment(department) {
    showDemoPapers();
    const paperCards = document.querySelectorAll('.paper-card');
    paperCards.forEach(card => {
      const paperDepartment = card.querySelector('.paper-meta p:nth-child(3)').textContent;
      if (!paperDepartment.toLowerCase().includes(department.toLowerCase())) {
        card.style.display = 'none';
      }
    });
  }
  
  // Clear filters
  clearFiltersBtn.addEventListener('click', async () => {
    document.getElementById('filter-subject').value = '';
    document.getElementById('filter-department').value = '';
    await fetchPapers();
  });
});