document.addEventListener('DOMContentLoaded', () => {
  const loginForm = document.getElementById('login-form');
  const loginError = document.getElementById('login-error');

  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    
    // Simple validation
    if (!email || !password) {
      showError('Please enter both email and password');
      return;
    }
    
    try {
      // For demo purposes, we're using a simple authentication
      // In a real application, you would validate against the server
      
      // Demo credentials (in a real app, this would be server-side)
      const validCredentials = [
        { email: 'admin@example.com', password: 'admin123' },
        { email: 'user@example.com', password: 'user123' }
      ];
      
      const user = validCredentials.find(
        user => user.email === email && user.password === password
      );
      
      if (user) {
        // Store login state
        sessionStorage.setItem('isLoggedIn', 'true');
        sessionStorage.setItem('userEmail', email);
        
        // Show success message
        showSuccess('Login successful! Redirecting to dashboard...');
        
        // Redirect to dashboard after a short delay
        setTimeout(() => {
          window.location.href = 'dashboard.html';
        }, 1000);
      } else {
        // Check if the user exists in localStorage (from registration)
        const registeredUsers = JSON.parse(localStorage.getItem('users') || '[]');
        const registeredUser = registeredUsers.find(
          user => user.email === email && user.password === password
        );
        
        if (registeredUser) {
          // Store login state
          sessionStorage.setItem('isLoggedIn', 'true');
          sessionStorage.setItem('userEmail', email);
          
          // Show success message
          showSuccess('Login successful! Redirecting to dashboard...');
          
          // Redirect to dashboard after a short delay
          setTimeout(() => {
            window.location.href = 'dashboard.html';
          }, 1000);
        } else {
          showError('Invalid email or password');
        }
      }
    } catch (error) {
      console.error('Login error:', error);
      showError('An error occurred during login');
    }
  });
  
  function showError(message) {
    loginError.textContent = message;
    loginError.classList.remove('hidden');
    loginError.classList.remove('success-message');
    loginError.classList.add('error-message');
  }
  
  function showSuccess(message) {
    loginError.textContent = message;
    loginError.classList.remove('hidden');
    loginError.classList.remove('error-message');
    loginError.classList.add('success-message');
  }
});