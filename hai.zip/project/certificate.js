document.addEventListener('DOMContentLoaded', () => {
  // Check if user is logged in
  const isLoggedIn = sessionStorage.getItem('isLoggedIn');
  if (!isLoggedIn) {
    alert('You must log in first!');
    window.location.href = 'login.html';
    return;
  }
  
  const certificateForm = document.getElementById('certificate-form');
  const verificationResult = document.getElementById('verification-result');
  
  certificateForm.addEventListener('submit', (e) => {
    e.preventDefault();
    
    const certificateId = document.getElementById('certificate-id').value;
    const studentName = document.getElementById('student-name').value;
    
    // For demo purposes, we'll simulate certificate verification
    // In a real application, this would query the blockchain
    
    verificationResult.innerHTML = '<p>Verifying certificate...</p>';
    verificationResult.className = 'verification-result';
    verificationResult.classList.remove('hidden');
    
    // Simulate API call delay
    setTimeout(() => {
      // Demo verification logic (in a real app, this would check the blockchain)
      const isValid = certificateId.length >= 8 && 
                      /^[A-Za-z0-9-]+$/.test(certificateId) && 
                      studentName.length > 3;
      
      if (isValid) {
        // Generate random certificate details for demo
        const courses = ['Computer Science', 'Electrical Engineering', 'Mechanical Engineering', 'Civil Engineering'];
        const randomCourse = courses[Math.floor(Math.random() * courses.length)];
        
        const years = [2022, 2023, 2024, 2025];
        const randomYear = years[Math.floor(Math.random() * years.length)];
        
        const grades = ['A', 'A-', 'B+', 'B'];
        const randomGrade = grades[Math.floor(Math.random() * grades.length)];
        
        verificationResult.innerHTML = `
          <div class="valid">
            <h3>✅ Certificate Verified</h3>
            <p>The certificate with ID <strong>${certificateId}</strong> for <strong>${studentName}</strong> is valid and registered in our blockchain.</p>
            
            <div class="certificate-details">
              <h4>Certificate Details:</h4>
              <p><strong>Student:</strong> ${studentName}</p>
              <p><strong>Certificate ID:</strong> ${certificateId}</p>
              <p><strong>Program:</strong> ${randomCourse}</p>
              <p><strong>Year of Completion:</strong> ${randomYear}</p>
              <p><strong>Grade:</strong> ${randomGrade}</p>
              <p><strong>Issued Date:</strong> ${new Date(randomYear, Math.floor(Math.random() * 12), Math.floor(Math.random() * 28) + 1).toLocaleDateString()}</p>
              <p><strong>Blockchain Verification:</strong> <span class="block-hash">${generateRandomHash()}</span></p>
            </div>
          </div>
        `;
        verificationResult.className = 'verification-result valid';
      } else {
        verificationResult.innerHTML = `
          <div class="invalid">
            <h3>❌ Certificate Not Found</h3>
            <p>We could not verify the certificate with ID <strong>${certificateId}</strong> for <strong>${studentName}</strong>.</p>
            <p>This could be due to one of the following reasons:</p>
            <ul>
              <li>The certificate ID is incorrect</li>
              <li>The student name does not match our records</li>
              <li>The certificate has not been registered in our blockchain</li>
              <li>The certificate may be fraudulent</li>
            </ul>
            <p>Please check the details and try again, or contact the institution that issued the certificate.</p>
          </div>
        `;
        verificationResult.className = 'verification-result invalid';
      }
    }, 1500);
  });
  
  // Helper function to generate a random hash for demo purposes
  function generateRandomHash() {
    const characters = '0123456789abcdef';
    let hash = '0x';
    for (let i = 0; i < 64; i++) {
      hash += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return hash;
  }
});