document.addEventListener('DOMContentLoaded', () => {
  const registerForm = document.getElementById('register-form');
  const registerMessage = document.getElementById('register-message');

  registerForm.addEventListener('submit', (e) => {
    e.preventDefault();
    
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirm-password').value;
    
    // Simple validation
    if (!name || !email || !password || !confirmPassword) {
      showMessage('Please fill in all fields', 'error');
      return;
    }
    
    if (password !== confirmPassword) {
      showMessage('Passwords do not match', 'error');
      return;
    }
    
    if (password.length < 8) {
      showMessage('Password must be at least 8 characters long', 'error');
      return;
    }
    
    // In a real application, you would send this data to the server
    // For this demo, we'll simulate a successful registration
    
    // Store user data in localStorage (for demo purposes only)
    // In a real app, this would be handled securely on the server
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    
    // Check if email already exists
    if (users.some(user => user.email === email)) {
      showMessage('An account with this email already exists', 'error');
      return;
    }
    
    // Add new user
    users.push({
      name,
      email,
      password // In a real app, this would be hashed
    });
    
    localStorage.setItem('users', JSON.stringify(users));
    
    // Show success message
    showMessage('Registration successful! You can now log in.', 'success');
    
    // Reset form
    registerForm.reset();
    
    // Redirect to login page after a delay
    setTimeout(() => {
      window.location.href = 'login.html';
    }, 2000);
  });
  
  function showMessage(message, type) {
    registerMessage.textContent = message;
    registerMessage.className = type === 'error' ? 'error-message' : 'success-message';
    registerMessage.classList.remove('hidden');
  }
});