document.addEventListener('DOMContentLoaded', async () => {
  // Check if user is logged in
  const isLoggedIn = sessionStorage.getItem('isLoggedIn');
  if (!isLoggedIn) {
    alert('You must log in first!');
    window.location.href = 'login.html';
    return;
  }
  
  const verifyBtn = document.getElementById('verify-btn');
  const verificationResult = document.getElementById('verification-result');
  const blockchainBlocks = document.getElementById('blockchain-blocks');
  
  // Function to load blockchain data
  async function loadBlockchainData() {
    try {
      blockchainBlocks.innerHTML = '<p>Loading blockchain data...</p>';
      
      const response = await fetch('/api/blockchain');
      const blockchain = await response.json();
      
      if (!blockchain || !blockchain.chain || blockchain.chain.length === 0) {
        blockchainBlocks.innerHTML = '<p>No blockchain data available</p>';
        // Show demo blockchain data
        showDemoBlockchain();
        return;
      }
      
      blockchainBlocks.innerHTML = '';
      
      // Display blocks in reverse order (newest first)
      blockchain.chain.slice().reverse().forEach((block, index) => {
        const actualIndex = blockchain.chain.length - 1 - index;
        const isGenesis = actualIndex === 0;
        
        const blockItem = document.createElement('div');
        blockItem.className = 'block-item';
        
        let blockContent = `
          <h3>Block #${actualIndex} ${isGenesis ? '(Genesis Block)' : ''}</h3>
          <p><strong>Hash:</strong> <span class="block-hash">${block.hash}</span></p>
          <p><strong>Previous Hash:</strong> <span class="block-hash">${block.previousHash}</span></p>
          <p class="block-timestamp"><strong>Timestamp:</strong> ${new Date(block.timestamp).toLocaleString()}</p>
        `;
        
        if (!isGenesis) {
          blockContent += `
            <div class="block-data">
              <details>
                <summary>Block Data</summary>
                <p><strong>Paper ID:</strong> ${block.data.id}</p>
                <p><strong>Title:</strong> ${block.data.title}</p>
                <p><strong>Subject:</strong> ${block.data.subject}</p>
                <p><strong>Department:</strong> ${block.data.department}</p>
                <p><strong>Questions:</strong> ${block.data.questions.length}</p>
                <p><strong>Created By:</strong> ${block.data.createdBy}</p>
              </details>
            </div>
          `;
        } else {
          blockContent += `
            <div class="block-data">
              <details>
                <summary>Genesis Block Data</summary>
                <pre>${JSON.stringify(block.data, null, 2)}</pre>
              </details>
            </div>
          `;
        }
        
        blockItem.innerHTML = blockContent;
        blockchainBlocks.appendChild(blockItem);
      });
    } catch (error) {
      console.error('Error loading blockchain data:', error);
      // Show demo blockchain data if server is not running
      showDemoBlockchain();
    }
  }
  
  // Function to show demo blockchain data
  function showDemoBlockchain() {
    const demoChain = [
      {
        index: 0,
        timestamp: Date.now() - 1000000,
        hash: "0x7f83b1657ff1fc53b92dc18148a1d65dfc2d4b1fa3d677284addd200126d9069",
        previousHash: "0",
        data: { message: "Genesis Block for College Question Papers" },
        isGenesis: true
      },
      {
        index: 1,
        timestamp: Date.now() - 800000,
        hash: "0x3f4fa19e5efe138d8e9b4923975c4a44d88b7f35d7d898470ec508ca9bc822c2",
        previousHash: "0x7f83b1657ff1fc53b92dc18148a1d65dfc2d4b1fa3d677284addd200126d9069",
        data: {
          id: "CS101-2025",
          title: "Introduction to Computer Science",
          subject: "Computer Science",
          department: "Computer Science and Engineering",
          examDate: "2025-05-15",
          createdBy: "Prof. Johnson",
          questions: [
            { text: "Explain the concept of object-oriented programming.", marks: 10 },
            { text: "Describe the difference between stack and queue data structures.", marks: 8 },
            { text: "What is the time complexity of quicksort in the worst case?", marks: 5 },
            { text: "Explain the working of a binary search algorithm.", marks: 7 }
          ]
        }
      },
      {
        index: 2,
        timestamp: Date.now() - 600000,
        hash: "0x6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b",
        previousHash: "0x3f4fa19e5efe138d8e9b4923975c4a44d88b7f35d7d898470ec508ca9bc822c2",
        data: {
          id: "EE202-2025",
          title: "Digital Electronics",
          subject: "Electronics",
          department: "Electrical Engineering",
          examDate: "2025-06-10",
          createdBy: "Prof. Williams",
          questions: [
            { text: "Design a 4-bit synchronous counter using JK flip-flops.", marks: 15 },
            { text: "Explain the working principle of a D/A converter.", marks: 10 },
            { text: "Implement a full adder circuit using NAND gates only.", marks: 10 }
          ]
        }
      },
      {
        index: 3,
        timestamp: Date.now() - 300000,
        hash: "0xd4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35",
        previousHash: "0x6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b",
        data: {
          id: "ME301-2025",
          title: "Thermodynamics",
          subject: "Mechanical Engineering",
          department: "Mechanical Engineering",
          examDate: "2025-05-20",
          createdBy: "Prof. Smith",
          questions: [
            { text: "State and explain the first law of thermodynamics.", marks: 8 },
            { text: "Derive the expression for Carnot efficiency.", marks: 12 },
            { text: "Explain the working of a four-stroke engine with diagrams.", marks: 15 }
          ]
        }
      }
    ];
    
    blockchainBlocks.innerHTML = '';
    
    // Add a note that this is demo data
    const demoNote = document.createElement('div');
    demoNote.className = 'demo-note';
    demoNote.innerHTML = '<p>Note: Showing demo blockchain data. Connect to server for real data.</p>';
    blockchainBlocks.appendChild(demoNote);
    
    // Display blocks in reverse order (newest first)
    demoChain.slice().reverse().forEach((block) => {
      const blockItem = document.createElement('div');
      blockItem.className = 'block-item';
      
      let blockContent = `
        <h3>Block #${block.index} ${block.isGenesis ? '(Genesis Block)' : ''}</h3>
        <p><strong>Hash:</strong> <span class="block-hash">${block.hash}</span></p>
        <p><strong>Previous Hash:</strong> <span class="block-hash">${block.previousHash}</span></p>
        <p class="block-timestamp"><strong>Timestamp:</strong> ${new Date(block.timestamp).toLocaleString()}</p>
      `;
      
      if (!block.isGenesis) {
        blockContent += `
          <div class="block-data">
            <details>
              <summary>Block Data</summary>
              <p><strong>Paper ID:</strong> ${block.data.id}</p>
              <p><strong>Title:</strong> ${block.data.title}</p>
              <p><strong>Subject:</strong> ${block.data.subject}</p>
              <p><strong>Department:</strong> ${block.data.department}</p>
              <p><strong>Questions:</strong> ${block.data.questions.length}</p>
              <p><strong>Created By:</strong> ${block.data.createdBy}</p>
            </details>
          </div>
        `;
      } else {
        blockContent += `
          <div class="block-data">
            <details>
              <summary>Genesis Block Data</summary>
              <pre>${JSON.stringify(block.data, null, 2)}</pre>
            </details>
          </div>
        `;
      }
      
      blockItem.innerHTML = blockContent;
      blockchainBlocks.appendChild(blockItem);
    });
  }
  
  // Load blockchain data on page load
  await loadBlockchainData();
  
  // Verify blockchain integrity
  verifyBtn.addEventListener('click', async () => {
    try {
      verificationResult.innerHTML = '<p>Verifying blockchain integrity...</p>';
      verificationResult.className = '';
      
      const response = await fetch('/api/validate');
      const result = await response.json();
      
      if (result.valid) {
        verificationResult.innerHTML = `
          <p>✅ Blockchain verification successful!</p>
          <p>The blockchain is valid and has not been tampered with.</p>
          <p>All question papers are secure and their integrity is maintained.</p>
        `;
        verificationResult.className = 'valid';
      } else {
        verificationResult.innerHTML = `
          <p>❌ Blockchain verification failed!</p>
          <p>The blockchain has been tampered with or is invalid.</p>
          <p>This indicates potential security issues with the question papers.</p>
        `;
        verificationResult.className = 'invalid';
      }
    } catch (error) {
      console.error('Error verifying blockchain:', error);
      // Show demo verification result if server is not running
      setTimeout(() => {
        verificationResult.innerHTML = `
          <p>✅ Blockchain verification successful!</p>
          <p>The blockchain is valid and has not been tampered with.</p>
          <p>All question papers are secure and their integrity is maintained.</p>
          <p><small>(Demo mode: Server connection not available)</small></p>
        `;
        verificationResult.className = 'valid';
      }, 1500);
    }
  });
});